﻿namespace CS_OOP_Advanced_Exam_Prep_July_2016.Lifecycle.Request
{
    public enum RequestMethod 
    {
        GET,
        ADD,
        EDIT,
        DELETE
    }
}
