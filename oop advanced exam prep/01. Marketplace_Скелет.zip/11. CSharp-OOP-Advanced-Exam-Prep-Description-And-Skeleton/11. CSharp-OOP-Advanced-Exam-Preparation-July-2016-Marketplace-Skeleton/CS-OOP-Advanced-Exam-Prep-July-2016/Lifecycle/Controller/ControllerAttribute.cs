﻿namespace CS_OOP_Advanced_Exam_Prep_July_2016.Lifecycle.Controller
{
    using System;

    public class ControllerAttribute : Attribute
    {
    }
}
