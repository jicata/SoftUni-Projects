﻿namespace CS_OOP_Advanced_Exam_Prep_July_2016.Parser
{
    public interface IParser
    {
        void Parse();
    }
}
