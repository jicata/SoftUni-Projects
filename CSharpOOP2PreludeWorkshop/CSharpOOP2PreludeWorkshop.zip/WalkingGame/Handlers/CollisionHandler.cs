﻿namespace WalkingGame.Handlers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AnimationHandler;
    using AnimationHandling;
    using Microsoft.Xna.Framework;
    using Models;

    public class CollisionHandler
    {
        private CharacterEntity character;
        List<FallingEntity> fallingEntities;

        public CollisionHandler(CharacterEntity character, List<FallingEntity> fallingEntities)
        {
            this.character = character;
            this.fallingEntities = fallingEntities;
        }

        public void CheckForCollision()
        {
            FallingEntity entity = null;
            foreach (var fallingEntity in this.fallingEntities)
            {
               var rect = new Rectangle((int)this.character.X, (int)this.character.Y, 16,16);
                if (rect.Intersects(fallingEntity.BBox))
                {
                    Task task = Task.Run(() => { Console.Beep(150, 500); });
                    //Console.Beep(150,500);
                    entity = fallingEntity;
                    break;

                }
            }
            this.fallingEntities.Remove(entity);
        }
    }
}
