﻿namespace WalkingGame.AnimationHandling
{
    using System.Collections.Generic;
    using System.IO;
    using Microsoft.Xna.Framework.Content;
    using Microsoft.Xna.Framework.Graphics;

    public static class AssetBufferer
    {
        public static List<Texture2D> textures = new List<Texture2D>();
        public static void BufferImages(ContentManager manager)
        {
            string path =
            @"C:\Users\Maika\Documents\visual studio 2015\Projects\CSharpOOP2PreludeWorkshop\WalkingGame\Content\FallingStuff";
            var currentDir = Directory.GetFiles(path);
            foreach (var fileName in currentDir)
            {
                string extractedFileName = fileName.Substring(99);
                string fileNameWithoutExtension = extractedFileName.Substring(0, extractedFileName.Length - 4);
                Texture2D texture = manager.Load<Texture2D>(fileNameWithoutExtension);
                textures.Add(texture);
            }
        }
    }
}
