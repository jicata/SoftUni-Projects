﻿namespace WalkingGame
{
    using Microsoft.Xna.Framework;
    using Microsoft.Xna.Framework.Graphics;
    using Microsoft.Xna.Framework.Input;
    using Models;

    public class CharacterEntity : GameObject
    {
        private Texture2D texture;
        private float x;
        private float y;

        public override float X
        {
            get { return this.x; }
            set { this.x = value; }
        }

        public override float Y
        {
            get { return this.y; }
            set { this.y = value; }
        }

        public override Texture2D Texture
        {
            get
            {
                return texture;
            }

            set
            {
                texture = value;
            }
        }

        public CharacterEntity(GraphicsDevice graphicsDevice)
        {
            if (Texture == null)
            {
                using (var stream = TitleContainer.OpenStream("Content/charactersheet.png"))
                {
                    Texture = Texture2D.FromStream(graphicsDevice, stream);
                }
            }
            this.X = Globals.GLOBAL_WIDTH/2;
            this.Y = Globals.GLOBAL_HEIGHT - 18;
        }
    }
}
