﻿namespace WalkingGame.Models
{
    using System;
    using Microsoft.Xna.Framework;
    using Microsoft.Xna.Framework.Graphics;

    public class FallingEntity: GameObject
    {
        public string name;
        public override Texture2D Texture { get; set; }
        public override float X { get; set; }
        public override float Y { get; set; }

        public FallingEntity(Texture2D texture, float x)
        {
            this.name = texture.Name;
            this.Texture = texture;
            this.X = x;
            this.Y = 0;
        }

        public Rectangle BBox
        {
            get { return  new Rectangle((int)this.X,(int)this.Y, this.Texture.Width, this.Texture.Height);}
        }
    }
}
