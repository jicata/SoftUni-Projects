﻿namespace WalkingGame.Models
{
    using System.Dynamic;
    using Microsoft.Xna.Framework.Graphics;

    public abstract class GameObject
    {
        public abstract Texture2D Texture { get; set; }
        public abstract float X { get; set; }
        public abstract float Y { get; set; }
    }
}
