﻿namespace WalkingGame.Factories
{
    using System;
    using AnimationHandling;
    using Microsoft.Xna.Framework;
    using Models;

    public static class FallingEntityFactory
    {
        private static double lastCall;

        public static FallingEntity ProduceEntity(GameTime gameTime)
        {
            if (lastCall + 0.5 <= gameTime.TotalGameTime.TotalSeconds)
            {
                lastCall = gameTime.TotalGameTime.TotalSeconds;
                int randomIndex = new Random().Next()%AssetBufferer.textures.Count;
                
                return new FallingEntity(AssetBufferer.textures[randomIndex], new Random().Next(0, Globals.GLOBAL_WIDTH));
            }
            else
            {
                return null;
            }
            
        }
    }
}
